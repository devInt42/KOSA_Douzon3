package edu.kosa.members;

import java.sql.Connection;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class MemberDAO {	// Controller
	
	private static MemberDAO instance = new MemberDAO();
	
	public static MemberDAO getInstance() {
		return instance;
	}
	
	private MemberDAO() {  }

	public Connection getConnection() throws Exception {
		Context initCtx = new InitialContext();
//		Context envCtx = (Context) initCtx.lookup("java:comp/env");
//		DataSource ds = (DataSource) envCtx.lookup("jdbc:MemberDB");
		DataSource ds = (DataSource) initCtx.lookup("java:comp/env/dbc:MemberDB");
		
		return ds.getConnection();
	} // getConnection() end
}








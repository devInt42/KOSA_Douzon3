package quiz2;

public class FileManager {

}

package quiz.one;

public class MainEntry {
	public static void main(String[] args) {
		SungJuk sj = new SungJuk();
		sj.input();
	}

}

/*package quiz.three;

import java.util.Scanner;

public class MainEntry {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Person p = new Person();
		Student s = new Student();
		Professor f = new Professor();
		System.out.println("1. 학생\t2. 교수");
		int job = sc.nextInt();
		if(job ==1) {
			s.input();
			s.disp();
		}

	}
}
*/
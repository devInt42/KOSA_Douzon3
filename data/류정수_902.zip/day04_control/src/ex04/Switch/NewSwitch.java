package ex04.Switch;

import java.util.Scanner;

public class NewSwitch {
	public static void main(String[] args) {
	System.out.println("원하는 달의 일수 확인 하기 : ");
	int month = new Scanner(System.in).nextInt(); //5월
	
	/*
	 * int day = switch(month) { case 1, 3, 5, 7, 8, 10, 12 -> {
	 * System.out.println("31일 까지 있음!"); yield 31; } case 4, 6, 9, 11 -> {
	 * System.out.println("30일 까지 있음!"); yield 31; } case 2 -> {
	 * System.out.println("28일까지 있음!"); yield 28; } default -> {
	 * System.out.println("없는 달입니다. 1~12월 까지만..."); yield 0; } }
	 */
	}
}

package quiz;

public class Add {
	public static void main(String[] args) {
		int num1;
		int num2;
	}
}

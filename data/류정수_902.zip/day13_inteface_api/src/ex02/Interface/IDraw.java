package ex02.Interface;

public interface IDraw {
	int su = 1000;	//static fianal
	public void draw();	//abstract
}

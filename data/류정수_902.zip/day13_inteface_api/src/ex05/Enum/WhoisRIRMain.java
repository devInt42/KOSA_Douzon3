package ex05.Enum;

public class WhoisRIRMain {
	public static void main(String[] args) {
		System.out.println(WhoisRIR.ARIN.url());
		System.out.println(WhoisRIR.JPNIC.url());
	}
}

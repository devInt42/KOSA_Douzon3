package ex04.operator;

//최단산쉬관놈삼대콤
public class OperatorTest {
	public static void main(String[] args) {
		// 관계연산자 : > , < , => , <=, ==, !=
		int x = 3, y = 5;
		
		boolean flag = true;
		System.out.println(!flag);

		if (x > y) {
			System.out.println("max : " + x);
		} 
		else {
			System.out.println("max : " + y);	
			
		}
		
		
		//  논리 연산자 : 2진 논리 		결과 : 참 , 거짓
		
		
		
		

	}
}

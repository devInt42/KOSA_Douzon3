package ex01.basic;

public class ToJava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

package ex06_For;

public class MainEntry {
	public static void main(String[] args) {
				for (int i =1 ; i <= 2; i++) {
					for (int j =1; j<=3; j++) {
						System.out.printf(j+"\t");
					}
					System.out.println("");
				}
				
				System.out.println("=====================");
				
			int i = 10;
			while(i>1) {//조건
				
				System.out.println(i);
				i--; //증감식
				
			} // 
				
				
	}
}

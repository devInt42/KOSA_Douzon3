package ex02.randomMethod;

public class MainEntry {
	public static void main(String[] args) {
		System.out.println(Math.E);
		System.out.println(Math.PI);
		System.out.println();
		// random(); 난수 발생 0.0 ~ 1.0
		System.out.println(Math.random());
	}
}

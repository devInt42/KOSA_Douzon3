//*
package quiz.two;

import java.util.Scanner;

public class MainEntry2 {
	public static void main(String[] args) {
		char ch = 'a';
		char ch2 = 'A';
		System.out.println((char)97);
	
	}
}
package ex07.inheritance;

public class Rectangle extends Point {
	private int x2, y2;
}

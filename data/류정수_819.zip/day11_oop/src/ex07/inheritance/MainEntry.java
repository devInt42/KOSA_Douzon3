package ex07.inheritance;

public class MainEntry {
	public static void main(String[] args) {
		Circle c = new Circle();
		Rectangle r = new Rectangle();
		Triangle t = new Triangle();
		Point p = new Point();
		c.disp();
	}
}

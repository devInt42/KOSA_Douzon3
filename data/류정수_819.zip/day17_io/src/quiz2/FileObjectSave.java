package quiz2;

public class FileObjectSave {

}

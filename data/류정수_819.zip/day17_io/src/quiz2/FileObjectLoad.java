package quiz2;

public class FileObjectLoad {

}

package ex01.scanner;

public class InputTest {

	public static void main(String[] args) {
		System.out.println("string, int = ");
		
		String str = args[0];
		String strSu = args[1];
		
		System.out.println(str);
		System.out.println(strSu);
		
	}

}

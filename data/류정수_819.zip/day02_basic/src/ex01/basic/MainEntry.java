package ex01.basic;

public class MainEntry {
	public static void main(String[] args) {
		System.out.println("Test Java");	
		  System.out.println("Test Java"); 
		  System.out.println("Test Java");
		  System.out.println("Test Java"); 
		  System.out.println("Test Java");
		  System.out.println("Test Java"); 
		  System.out.println("Test Java");
		
	}
}

package quiz.two;

public class Video {
	 protected String 
	 title, //비디오제목
		category, //장르
		lend, //대여여부
		lendName, // 대여자(고객명)
		lendDate;  // 대여일자(오늘날짜 입력하심 되요)
}

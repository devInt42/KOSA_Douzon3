package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import dbConn.util.CloseHelper;
import dbConn.util.ConnectionHelper;
import model.UserVO;

public class MarketController {
	// 연결, 삽입, 삭제, 수정, 검색,......
	static Scanner sc = new Scanner(System.in);
	static Statement stmt = null;
	static ResultSet rs = null;
	static Connection conn = null;
	static PreparedStatement pstmt = null;

	// connect
	public static void connect() {
		try {
			conn = ConnectionHelper.getConnection("oracle");
			stmt = conn.createStatement();
			conn.setAutoCommit(false); // 자동커밋 끄기
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// close
	public static void close() {
		try {
			CloseHelper.close(rs);			CloseHelper.close(stmt);			CloseHelper.close(pstmt);			CloseHelper.close(conn);
		} catch (Exception e) {  e.printStackTrace();  }		
	}	
		// menu
		public static void menu() throws SQLException {  // 예외처리 위임
			UserVO  vo = new UserVO();
			while( true ) {
				System.out.println();
				
				ConnectionHelper.menu();
				System.out.println("\t 0. rollback   ");
				System.out.print("\t 9. commit   ");
				switch ( sc.nextInt() ) {
					case 0 : System.out.println("Commit 하시겠습니까?(Y/N) ");
							System.out.println("안하시려면 Rollback 됩니다. ");
							if( sc.next().equalsIgnoreCase("Y") ) {
								conn.commit();  // 예외발생
								selectAll(vo.getClassName());
							} else {
								conn.rollback();  
								selectAll(vo.getClassName());
							}
						break;
		
					case 1:
						selectAll(vo.getClassName());
//						insert();
						selectAll(vo.getClassName());
						break;
					case 2:	selectAll(vo.getClassName());
						update(vo.getClassName());
						selectAll(vo.getClassName());
						break;
					case 3:	selectAll(vo.getClassName());
						break;
					case 4:	selectByGno(vo.getClassName());
						break;
					case 5:	
						
								selectAll(vo.getClassName());
								delete(vo.getClassName());
								break;
					case 6:	close();
							System.out.println("프로그램 종료합니다.!!");
							System.exit(0);					
							break;
					case 9 :  conn.commit();
						System.out.println("성공적으로 완료 되었습니다.");
						break;
						
					default: System.out.println("없는 번호 선택 하셨습니다. 0~6, 9번 중에서 선택하세요.");
						break;
				} // end switch
				
			} // end while
		} // end menu
	







}



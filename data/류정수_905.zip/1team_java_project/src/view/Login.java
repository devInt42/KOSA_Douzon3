package view;

import java.sql.SQLException;

import controller.LoginController;


public class Login {
	public static void main(String[] args) throws SQLException {
		LoginController.connect();
		menu();

		}
		public static void menu() {
			System.out.println("\n-=-=-=-= JDBC Query-=-=-=-=-");
			
			System.out.println("\t 0. 롤백한다 ");
			System.out.println("\t 1. 로그인 ");
			System.out.println("\t 2. 회원가입 ");
			
			System.out.println("\t 3. 회원탈퇴 ");
			System.out.println("\t 4. 프로그램 종료 ");
			System.out.println("\t 9. 커밋 ");
			
		System.out.println();
			System.out.println("\t >> 원하는 메뉴 선택하세요.  ");
		}
}

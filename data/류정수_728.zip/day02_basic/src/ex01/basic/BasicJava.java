package ex01.basic;

public class BasicJava {
	public static void main(String[] args) {
		System.out.println("류정수");
	}
}

package quiz2;

import java.util.ArrayList;

public class MainEntry {
	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();
		
		
		
		
	}
}

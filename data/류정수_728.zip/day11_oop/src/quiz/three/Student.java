package quiz.three;

import java.util.Scanner;

public class Student extends Person {
	private String major;
	private int no, grade;
	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
	
		this.major = major;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

	public void input() {
		
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("학과 : ");
		setMajor(sc.next());
		System.out.println("학번 : ");
		setNo(sc.nextInt());
		System.out.println("학년 : ");
		setGrade(sc.nextInt());

	}

	public void disp() {
		System.out.println("학생 이름 : " + name + "\t키 : " + getHeight() + "\t몸무게 : " + getWeight());
		System.out.println("학생 학과 : " + major + "\t학번 : " + no + "\t학년 : " + grade);

	}
}

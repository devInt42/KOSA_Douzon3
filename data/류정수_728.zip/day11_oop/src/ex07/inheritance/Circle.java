package ex07.inheritance;

public class Circle extends Point{
private int r;

public void disp() {
	System.out.println("원 : " + x + ", "+ y + "r "+ r );
}

}

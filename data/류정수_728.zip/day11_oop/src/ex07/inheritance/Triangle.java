package ex07.inheritance;

public class Triangle extends Point {
	
}

package ex03.multi;

public interface Test {
	String message = "Th3";
	public void tshow(String name);
	
	
}

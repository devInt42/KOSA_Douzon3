package quiz;

import java.util.Scanner;
//3의배수

public class ForLoop {
	public static void main(String[] args) {
		for(int i=0;i<=100;i++) {
			if(i%5==0)
			System.out.println(i);
		}
	}

}

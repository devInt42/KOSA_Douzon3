package ex05.oop;

public class MainEntry {
public static void main(String[] args) {
	Point pt = new Point();
	pt.setX(1);
	pt.setY(2);
	pt.display();


	Rect r = new Rect();
	r.setX(1);
	r.setX2(2);
	r.setY(3);
	r.setY2(4);
	r.display();
}

}

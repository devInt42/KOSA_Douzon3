package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import dbConn.util.CloseHelper;
import dbConn.util.ConnectionHelper;
import model.CustomerVO;

public class MarketController {
	// 연결, 삽입, 삭제, 수정, 검색,......
	static Scanner sc = new Scanner(System.in);
	static Statement stmt = null;
	static ResultSet rs = null;
	static Connection conn = null;
	static PreparedStatement pstmt = null;
	static String CNO = null;

	// connect
	public static void connect() {
		try {
			conn = ConnectionHelper.getConnection("oracle");
			stmt = conn.createStatement();
			conn.setAutoCommit(false); // 자동커밋 끄기
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String login() throws SQLException {
		CNO = LoginController.menu();
		System.out.println(CNO);
		return CNO;
	}

	// close
	public static void close() {
		try {
			CloseHelper.close(rs);
			CloseHelper.close(stmt);
			CloseHelper.close(pstmt);
			CloseHelper.close(conn);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// menu
	public static void menu() throws SQLException { // 예외처리 위임
		if (CNO == null) {
			CNO = login();
			System.out.println(CNO);
		}
		while (true) {
			System.out.println();
			menuList();
			switch (sc.nextInt()) {
			case 0:
				System.out.println("Commit 하시겠습니까?(Y/N) ");
				System.out.println("안하시려면 Rollback 됩니다. ");
				if (sc.next().equalsIgnoreCase("Y")) {
					conn.commit(); // 예외발생
				} else {
					conn.rollback();
				}
				break;

			case 1:
				ItemController.selectAll(CNO);
				break;
			case 2:
				ItemController.insert(CNO);
				break;
			case 3:
				System.out.println("case3 " + CNO);
				break;
			case 4:
				System.out.println("case4 " + CNO);
				break;
			default:
				break;
			}
		}
	} // end menu

	public static void menuList() {
		System.out.println("\n======= 떡잎 마켓=======");
		System.out.println("\t 1. 물품 목록 ");
		System.out.println("\t 2. 판매 물품 등록");
		System.out.println("\t 3. 채팅하기 ");
		System.out.println("\t 4. 사용자 정보 ");
		System.out.println("\t 5. 프로그램 종료 ");
//      System.out.println("\t 6. 회원 관리 ");
		System.out.print(">> 원하는 메뉴 선택하세요  : ");
	}

}

package controller;

import java.io.DataInputStream;

import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import dbConn.util.CloseHelper;
import dbConn.util.ConnectionHelper;

public class Chat {
	static String userName = null;
	static boolean seller = false;
	static String iname = null;
	static Scanner sc = new Scanner(System.in);
	static Statement stmt = null;
	static ResultSet rs = null;
	static Connection conn = null;
	static PreparedStatement pstmt = null;

	public static void connect() {
		try {
			conn = ConnectionHelper.getConnection("oracle");
			stmt = conn.createStatement();
			conn.setAutoCommit(false);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void close() {
		try {
			CloseHelper.close(rs);
			CloseHelper.close(stmt);
			CloseHelper.close(pstmt);
			CloseHelper.close(conn);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void start(int INO, int CNO) throws SQLException {
		Thread sender = null;
		Thread receiver = null;

		connect();

		// 현재 채팅을 실행한 유저가 판매자인지 판단
		pstmt = conn.prepareStatement("SELECT * FROM ITEM WHERE INO = ? ");
		pstmt.setInt(1, INO);
		rs = pstmt.executeQuery();

		// 판매자면 seller true;
		while (rs.next()) {
			iname = rs.getString(2);
			if (rs.getInt(4) == CNO)
				seller = true;
		}

		// 현재 유저의 이름 찾기
		pstmt = conn.prepareStatement("SELECT CNAME FROM CUSTOMER WHERE CNO = ? ");
		pstmt.setInt(1, CNO);
		rs = pstmt.executeQuery();
		while (rs.next())
			userName = rs.getString(1);

		// 메인함수에 들여온 함수인자가 존재할 시
		try {
			String ip = "192.168.110.27"; // ip값 초기화
			Socket s = new Socket(ip, 7777);

			System.out.println("떡잎마켓의 " + iname + "의 거래 채팅방입니다. ");
			System.out.println("채팅방을 종료하고 싶으시면 종료 를 입력하시면 됩니다.");
			sender = new Thread(new ClientSender(s, userName, seller)); // thread객체 sender를 생성 : 생성된 객체 sender는
			// ClientSender클래스 객체이다. 여기서 2번을 확인한다.
			receiver = new Thread(new ClientReceiver(s));
			sender.start();
			receiver.start();

		} catch (Exception e) {
			e.printStackTrace();
		}

		while (true) {

			@SuppressWarnings("null")
			Thread.State sender_state = sender.getState();
			Thread.State receiver_state = receiver.getState();
			if (sender_state == Thread.State.TERMINATED || receiver_state == Thread.State.TERMINATED) {
				System.out.println("채팅방을 종료하고 메뉴로 돌아갑니다. ");
				return;

			}
		}

	}// main end
		// 2. ClientSender : 클라이언트에서 server에 무언가를 보내는 클래스

	static class ClientSender extends Thread { // inner class

		Socket s; // socket
		DataOutputStream dos; // dataoutputstream : 파일에 데이터를 입력한다.
		String name;
		boolean seller;

		public ClientSender(Socket s, String name, boolean seller) { // 생성자 함수
			this.s = s;
			try {
				dos = new DataOutputStream(s.getOutputStream()); // Socket의 outputstream을 할당받는다. 즉 Socket에서 Data를 전송할 수
				// 있는 방법을 가져온다.

				this.name = name;
				this.seller = seller;

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		@Override
		public void run() { // override 된것을 확인할 수 있다. 이는 Runnable interface의 run 함수를 오버라이딩한 것이다.
			// ClientSender는 thread클래스를 확장했기 때문에 부모 클래스인 thread클래스가 implements한 Runnable
			// 인터페이스를 사용할 수 있기 때문이다. (자식 클래스는 부모 클래스의 모든 기능을 상속받는다.)
			Scanner sc = new Scanner(System.in);
			try {
				String user = null;
				if (seller == false) {
					user = "[구매자]" + name;
				} else
					user = "[판매자]" + name;

				if (dos != null) {
					dos.writeUTF(name);
					dos.writeBoolean(seller);// thread를 시작했을 때, 소켓의 outputstream이 열려있었다면, args로 입력받았던 name값을 전달한다.
				}
				while (dos != null) {
					String chat = sc.nextLine();
					if (chat.equals("종료")) {
						try {
							s.close();
							dos = null;
						} catch (SocketException e) {
							return;
						}
					}
					dos.writeUTF(user + ": " + chat);
				} // 이후 while문을 돌면서, [이름]:채팅 내용 을 UTF형식으로 전송한다.
			} catch (Exception e) {
			}
		} // end run()

	} // end ClientSender class

	// ClientRecevier는 thread를 확장하였다. -> thread클래스를 상속받았다.
	// 이 함수는 thread를 사용해 서버로부터 소켓(데이터)을 전달받는다.
	static class ClientReceiver extends Thread {

		Socket s;
		DataInputStream dis; // DataInputStream은 전달받은 데이터를 데이터타입별로 입력받는다.

		public ClientReceiver(Socket s) {
			this.s = s;
			try {
				dis = new DataInputStream(s.getInputStream()); // 소켓에 생성된 InputStream을 DatainputStream으로 받아온다.
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		@Override
		public void run() {
			while (dis != null) { // * 현재 슬레드는 지속적으로 상대방 서버로부터 데이터가 오는지 확인하고, 만약 데이터가 왔다면 println으로 읽은 값을 출력한다.
				try {
					if (s.isClosed()) {
						try {
							s.close();
							dis = null;
						} catch (SocketException e) {
							return;
						}
					}
					try {
						System.out.println(dis.readUTF());
					} catch (NullPointerException e) {
					}
				} catch (SocketException e) {
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	} // end ClientSender class

}
package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.Scanner;
import java.util.regex.Pattern;

import dbConn.util.CloseHelper;
import dbConn.util.ConnectionHelper;

public class BuyerController {
	static Scanner sc = new Scanner(System.in);
	static Statement stmt = null;
	static ResultSet rs = null;
	static Connection conn = null;
	static PreparedStatement pstmt = null;
	static String CNO = null;
	static int INO = 0;
	static int CMANAGER;

	public static void menuList(int CMANAGER) {
		System.out.println("\n======= 떡잎 마켓=======\n");
		System.out.println("\t 1. 물품 목록 ");
		System.out.println("\t 2. 판매 물품 등록");
		System.out.println("\t 3. 채팅하기 ");
		System.out.println("\t 4. 사용자 정보 ");
		System.out.println("\t 5. 프로그램 종료 ");
		if (CMANAGER == 1) {
			System.out.println("\n======= 관리자 ========\n");
			System.out.println("\t 6. 회원 관리 ");

		}
		System.out.println("\n=====================");

		System.out.print(">> 원하는 메뉴 선택하세요  : ");
	}

	public static void menu(String CNO, int INO) throws SQLException { // 예외처리 위임

		while (true) {
			System.out.println();
			menuList(CMANAGER);
			switch (sc.nextInt()) {
			case 0:
				System.out.println("Commit 하시겠습니까?(Y/N) ");
				System.out.println("안하시려면 Rollback 됩니다. ");
				if (sc.next().equalsIgnoreCase("Y")) {
					conn.commit(); // 예외발생
				} else {
					conn.rollback();
				}
				break;

			case 1:
				selectMySellList(CNO);
				;
				break;
			case 2:
				insert(INO);
				break;
			case 3:

				close();
				System.out.println("프로그램 종료합니다!");
				System.exit(0);
				break;
			default:
				System.out.println("1~5중에서 입력하세요");
				break;
			}
		}

	}

	public static void selectMySellList(String CNO) throws SQLException {
		pstmt = conn.prepareStatement("SELECT * FROM ITEM WHERE SELLER_CNO = ?");
		pstmt.setString(1, CNO);
		rs = pstmt.executeQuery();

		while (rs.next()) {

			int ino = rs.getInt(1);
			System.out.println("상품번호\t :  " + ino);
			String iname = rs.getString(2);
			System.out.println("상품이름\t :  " + iname);
			String iprice = rs.getString(3);
			System.out.println("상품가격\t :  " + iprice);
			String Seller_CNO = rs.getString(4);
			System.out.println("판매자 \t :  " + Seller_CNO);
			String chat = rs.getString(5);
			System.out.println("채팅방 \t :  " + chat);
			System.out.println();

		} // end while
	}

	public static void insert(int INO) throws SQLException {

		try {
			pstmt = conn.prepareStatement("insert into trade select * from item where ino = ?)");
			pstmt.setInt(1, INO);

			System.out.println("정말 구매하시겠습니까?(Y/N)");
			if (sc.next().equalsIgnoreCase("Y")) {
				// 예외발생
				int result = pstmt.executeUpdate();
				commit();
				System.out.println("구매되었습니다");
			} else {
				rollback();
				System.out.println("롤백했습니다");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// connect
	public static void connect() {
		try {
			conn = ConnectionHelper.getConnection("oracle");
			stmt = conn.createStatement();
			conn.setAutoCommit(false); // 자동커밋 끄기
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// close
	public static void close() {
		try {
			CloseHelper.close(rs);
			CloseHelper.close(stmt);
			CloseHelper.close(pstmt);
			CloseHelper.close(conn);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// rollback
	public static void rollback() throws SQLException {
		conn.rollback();
		System.out.println("롤백성공");
	}

	// commit
	public static void commit() throws SQLException {
		conn.commit();
		System.out.println("커밋성공");
	}
}
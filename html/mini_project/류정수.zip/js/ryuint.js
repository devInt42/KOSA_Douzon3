function hrefInsta() {
	location.href = "https://www.instagram.com/integer_42/";
}

function hrefMBTI() {
	location.href = "https://www.16personalities.com/istp-personality";
}

function hrefProject() {
	location.href = "ryuproject.html";
}
function hrefRyuint() {
	location.href = "ryuint.html";
}


function hrefMail() {
	window.location = "mailto:integer402@gmail.com";
}
